//
// Copyright (c) 2016 Advanced Micro Devices, Inc. All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// file_to_header.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <string>



#ifdef _WIN32
const char* const s_begin = "#pragma once\n\n"
                "const amf_uint8 %S[] = \n{\n\t";
const char* const s_end = "\n};\n\n";
const char* const s_size = "const amf_size %SCount=%d;\n\n";
int _tmain(int argc, _TCHAR* argv[])
#else
const char* const s_begin = "#pragma once\n\n"
                "const amf_uint8 %s[] = \n{\n\t";
const char* const s_end = "\n};\n\n";
const char* const s_size = "const amf_size %sCount=%d;\n\n";
int main(int argc, char* argv[])
#endif
{
    if(argc < 3)
    {
        return -1;
    }
#ifdef _WIN32
    std::wstring path = argv[1];
    std::wstring array_name = argv[2];
    std::wstring new_path = path + L".h";
    FILE* inFile = _wfopen(path.c_str(), L"rb");
#else
    std::string path = argv[1];
    std::string array_name = argv[2];
    std::string new_path = path + ".h";
    FILE* inFile = fopen(path.c_str(), "rb");
#endif
    if(inFile == 0)
        return -1;
#ifdef _WIN32
    FILE* outFile = _wfopen(new_path.c_str(), L"wb");
#else
    FILE* outFile = fopen(new_path.c_str(), "wb");
#endif
    if(outFile == 0)
        return -1;
    unsigned char data;

    char tmp_string[1024];
    int ready = sprintf(tmp_string, s_begin, array_name.c_str());

    fwrite(tmp_string, ready, 1, outFile);
    size_t size = 0;
    std::string coma;
    std::string ret = "\n\t";
    while(fread(&data, 1, 1, inFile))
    {
        if(coma.size())
        {
            fwrite(coma.c_str(), coma.size(), 1, outFile);
        }
        if(size && (size%8) == 0)
            fwrite(ret.c_str(), ret.size(), 1, outFile);

        ready = sprintf(tmp_string, "0x%0.2X", data);
        fwrite(tmp_string, ready, 1, outFile);
        coma = ", ";

        size++;
    }
    ready = sprintf(tmp_string, s_end);
    fwrite(tmp_string, ready, 1, outFile);
    ready = sprintf(tmp_string, s_size, array_name.c_str(), size);
    fwrite(tmp_string, ready, 1, outFile);
    fclose(inFile);
    fclose(outFile);

    return 0;
}

